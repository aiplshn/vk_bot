# -*- coding: utf-8 -*-
import vk_api
import time
import json
import requests
token="vk1.a.DoW2Qze3bc0GXGJPQkTlWGc1lsWPzs6x90FPXCntW8S6NNpPi4Cz-rZbFjdDixxoSBrMtP5qtyilUxYDKJ_SmFd_V_uocFgabBS4mFNuKDxdmfzYmdDrpusam2hj2zWESCm926QexMsS71QzzRfl9M5n6r0mMUEjkwaMCjyKA26T16jhnDr7x06jen2Qrx--R1jRphG3zoT1h_nv2usy0g"
 
# vk = vk_api.VkApi(login="", password="")
vk = vk_api.VkApi(token=token)
 
# vk.auth()
 
#  vk._auth_token()
 
def photo(user_id):
    a = vk.method("photos.getMessagesUploadServer")
    b = requests.post(a['upload_url'], files={'photo': open('полный путь к фотографии', 'rb')}).json()
    c = vk.method('photos.saveMessagesPhoto', {'photo': b['photo'], 'server': b['server'], 'hash': b['hash']})[0]
    vk.method("messages.send", {"peer_id": user_id, "message": "Фотка", "attachment": f'photo{c["owner_id"]}_{c["id"]}'})
 
 
while True:
    try:
        messages = vk.method("messages.getConversations", {"offset": 0, "count": 20, "filter": "unread"})
        if messages["count"] >= 1:
            #  print(messages)
            id = messages['items'][0]['last_message']['peer_id']
            body = messages['items'][0]['last_message']['text']
            if body.lower() == "фото":
                photo(id)
    except Exception as E:
        time.sleep(1)