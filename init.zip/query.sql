--CREATE TABLE tb(id INT NOT NULL PRIMARY KEY )
-- INSERT INTO tb VALUES (1)
-- USE sqlite_python.db;
SELECT * FROM admin;


-- CREATE TABLE admin (
--     id    INTEGER PRIMARY KEY
--                   NOT NULL,
--     state INTEGER
-- );


-- CREATE TABLE user (
--     id INTEGER PRIMARY KEY
--              NOT NULL
-- );

-- CREATE TABLE message (
--     id         INTEGER        PRIMARY KEY
--                               NOT NULL,
--     text       VARCHAR (2000),
--     photo_path VARCHAR (255),
--     video_path VARCHAR (255),
--     audio_path VARCHAR (255),
--     id_admin   INTEGER        REFERENCES admin (id) 
-- );
